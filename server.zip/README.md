# Mixwer
Belender answers of tests in JCT

first, clone the project
**git clone https://github.com/avishaigonen123/TestsShuffler**

after clonning, navigate to project dir
**cd /path/to/TestsShuffler**

then, activate the setup.py file
**pip install .**

lastly, run the server
**python server/server.py**
